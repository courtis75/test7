

<?php $__env->startSection('content'); ?>
    

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Blog Posts</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group me-2">
            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-sm btn-outline-secondary">Create Post</a><br><br>
          
           
          </div>
        
        </div>
    </div>

  
    <form action="<?php echo e(route('posts.search')); ?>" method="GET">
        <div class="form-group">
            <input type="text" name="query" class="form-control" placeholder="Search for posts">
        </div>
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
   

    
    <div>
 
      <ul>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
           <a href ="<?php echo e(route('posts.show',$post->id)); ?>"-><?php echo e($post->title); ?></a>
          </li>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

    </div>

   
  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test7\resources\views/Posts/index.blade.php ENDPATH**/ ?>