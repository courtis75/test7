

<?php $__env->startSection('content'); ?>
    
    <a href="<?php echo e(url('admin/posts')); ?>">Back</a>
   
    <a href="<?php echo e(route('admin/users.edit', ['id' => $user->_id])); ?>">Edit</a>

    <!-- Delete Button -->
    <form action="<?php echo e(route('admin/users.destroy', ['id' => $user->_id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

         <!-- Checkbox to delete all associated posts -->
         <div>
            <input type="checkbox" name="delete_posts" id="deletePostsCheckbox" value="yes">
            <label for="deletePostsCheckbox">Delete all posts associated with this User</label>
        </div>
    
        <button type="submit" onclick="return confirm('Are you sure you want to delete this User?')">Delete</button>
        
    </form>
    <ul>
       <li>
           ID:<?php echo e($user->id); ?>

       </li>
       <li>
           name:<?php echo e($user->name); ?>

       </li>
       <li>
           email:<?php echo e($user->email); ?>

       </li>
       <li>
           password:<?php echo e($user->password); ?>

       </li>
    </ul>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test7\resources\views/admin/users/showEach.blade.php ENDPATH**/ ?>