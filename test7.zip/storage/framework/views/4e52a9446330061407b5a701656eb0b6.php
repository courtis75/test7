

<?php $__env->startSection('content'); ?>
    
    <h1>Blog Posts details</h1>

    <div style="margin-bottom: 20px;">
    
    </div>

    <div style="display: flex; gap: 20px;">
        <div>
            <h2>Posts</h2>
            <ul style="list-style-type: none;">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                    <a href="<?php echo e(route('admin/posts.showEach', ['id' => $post->_id])); ?>"><?php echo e($post->title); ?></a>
                    </li>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div>
            <h2>Users</h2>
            <ul style="list-style-type: none;">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('admin/posts.show', $user->id)); ?>"><?php echo e($user->email); ?></a>
                    </li>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test7\resources\views/Admin/show.blade.php ENDPATH**/ ?>