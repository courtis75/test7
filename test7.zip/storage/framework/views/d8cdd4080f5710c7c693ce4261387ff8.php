

<?php $__env->startSection('content'); ?>
    
    <a href="<?php echo e(url('admin/posts')); ?>">Back</a>
   
    <a href="<?php echo e(route('admin/posts.edit', ['id' => $post->_id])); ?>">Edit</a>

    <!-- Delete Button -->
    <form action="<?php echo e(route('admin/posts.destroy', ['id' => $post->_id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    
        <button type="submit" onclick="return confirm('Are you sure you want to delete this post?')">Delete</button>
        
    </form>
    <ul>
       <li>
           ID:<?php echo e($post->id); ?>

       </li>
       <li>
           title:<?php echo e($post->title); ?>

       </li>
       <li>
           Content:<?php echo e($post->content); ?>

       </li>
    </ul>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test7\resources\views/admin/posts/showEach.blade.php ENDPATH**/ ?>