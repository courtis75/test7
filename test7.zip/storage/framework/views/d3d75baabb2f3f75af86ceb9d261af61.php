

<?php $__env->startSection('content'); ?>
    
    <h1 style="margin-left: 35px;">Admin Panel: Post + User details</h1>

    <div style="margin-bottom: 20px;">

        <div style="display: flex; gap: 20px; flex-direction: column;">

            <div>
                <h2 style="margin-left: 40px;">Posts</h2>

                <form action="<?php echo e(route('posts.create')); ?>" method="GET" style="display: inline;">
                    <button type="submit" class="btn btn-primary" style="margin-left: 40px;">Create New Post</button>
                </form>

                <ul style="list-style-type: none;">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('admin/posts.showEach', ['id' => $post->_id])); ?>">
                                <?php echo e($post->title); ?> 
                                
                                <?php if($post->user): ?>
                                    <span style="margin-left: 100px;color: red"><strong>by <?php echo e($post->user->email); ?></strong></span>
                                <?php else: ?>
                                    <span style="margin-left: 100px;color: red"><strong>by Unknown</strong></span>
                                <?php endif; ?>
                            </a>
                        </li>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            
            <div>
                <h2 style="margin-left: 40px;">Users</h2>

                <form action="<?php echo e(route('register')); ?>" method="GET" style="display: inline;">
                    <button type="submit" class="btn btn-secondary" style="margin-left: 40px;">Register New User</button>
                </form>

                <ul style="list-style-type: none;">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('admin/users.showEach', $user->id)); ?>"><?php echo e($user->email); ?></a>
                            <span style="margin-left: 20px;"> <?php echo e($user->role); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test7\resources\views/Admin/posts/show.blade.php ENDPATH**/ ?>