

<?php $__env->startSection('content'); ?>
    
    <h1>Admin Panel</h1>

        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="title">Content</label>
            <textarea name = "content" class="form-control" required></textarea>
           
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test7\resources\views/admin/create.blade.php ENDPATH**/ ?>