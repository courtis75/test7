

<?php $__env->startSection('content'); ?>
    <h1>Edit User</h1>

    <form action="<?php echo e(route('admin/users.update', $user->_id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label for="name">Name</label>
            <input type="text" id="name" name="name" value="<?php echo e($user->name); ?>">
        </div>

        <div>
            <label for="email">Email</label>
            <textarea id="email" name="email"><?php echo e($user->email); ?></textarea>
        </div>

        <div>
            <label for="password">Password</label>
            <textarea id="password" name="password"><?php echo e($user->password); ?></textarea>
        </div>

        <button type="submit">Update User</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test7\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>