

<?php $__env->startSection('content'); ?>
    
    <a href = "<?php echo e(url()->previous()); ?>">Back</a>
    <ul>
       <li>
           ID:<?php echo e($post->id); ?>

       </li>
       <li>
           title:<?php echo e($post->title); ?>

       </li>
       <li>
           Content:<?php echo e($post->content); ?>

       </li>
    </ul>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\test7\resources\views/Admin/showEach.blade.php ENDPATH**/ ?>