import './bootstrap';

import './color-modes';
import './dashboard';

import '@docsearch/js';
