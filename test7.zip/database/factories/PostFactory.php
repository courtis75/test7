<?php

namespace Database\Factories;

use App\Models\Post;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class PostFactory extends Factory
{
    protected $model = Post::class;
    /**
     
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title'  => $this -> faker -> sentence(),
            'content' => $this -> faker -> paragraph(),
        ];
    }
}
